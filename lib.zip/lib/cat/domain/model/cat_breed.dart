import 'package:flutter_application_1/cat/domain/model/cat_breed_image.dart';
import 'package:genq/genq.dart';

part 'cat_breed.genq.dart';

@genq
class CatBreed with _$CatBreed {
  factory CatBreed({
    required String id,
    required List<CatBreedImage> images,
    String? name,
    String? origin,
    String? lifeSpan,
    int? intelligence,
    String? description,
    String? wikipediaUrl,
  }) = _CatBreed;

  factory CatBreed.empty() {
    return CatBreed(id: '', images: []);
  }
}
