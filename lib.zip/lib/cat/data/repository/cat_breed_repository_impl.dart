import 'dart:convert';

import 'package:flutter_application_1/cat/data/mapper/cat_breed_images_list_mapper.dart';
import 'package:flutter_application_1/cat/data/model/cat_breed_images_list/cat_breed_image_response.dart';
import 'package:flutter_application_1/cat/data/model/cat_breed_list/cat_breed_response.dart';
import 'package:flutter_application_1/cat/domain/model/cat_breed_image.dart';
import 'package:http/http.dart' as http;

import '../../domain/model/cat_breed.dart';
import '../../domain/repository/cat_breed_repository.dart';
import '../mapper/cat_breed_list_mapper.dart';

class CatBreedRepositoryImpl extends CatBreedRepository {
  CatBreedRepositoryImpl({
    required CatBreedListMapper catBreedListMapper,
    required CatBreedImagesListMapper catBreedImageListMapper,
  }) : _catBreedListMapper = catBreedListMapper,
       _catBreedImageListMapper = catBreedImageListMapper;

  final CatBreedListMapper _catBreedListMapper;
  final CatBreedImagesListMapper _catBreedImageListMapper;

  final _baseUrl = 'https://api.thecatapi.com/v1';

  @override
  Future<List<CatBreed>> fetchBreeds() async {
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'x-api-key': 'bda53789-d59e-46cd-9bc4-2936630fde39',
    };

    final url = Uri.parse('$_baseUrl/breeds');
    final response = await http.get(url, headers: headers);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body) as List;
      final catBreedListResponse = jsonData.map((item) => $CatBreedResponseFromJson(item)).toList();
      return _catBreedListMapper.map(catBreedListResponse);
    } else {
      throw Exception('Unexpected error with status ${response.statusCode} because of ${response.reasonPhrase}');
    }
  }

  @override
  Future<List<CatBreedImage>> fetchBreedImages(String breedId) async {
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      //'x-api-key': 'live_JBT0Ah0Nt12iyl2IpjQVLDWjcLk0GQwf4zI9wBMfmfejKmcC31mOJp4yJz5TsOUP',
    };

    final url = Uri.parse(
        '$_baseUrl/images/search'
        '?limit=10'
        '&breed_ids=$breedId'
        '&api_key=live_JBT0Ah0Nt12iyl2IpjQVLDWjcLk0GQwf4zI9wBMfmfejKmcC31mOJp4yJz5TsOUP',
      );
    final response = await http.get(url, headers: headers);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body) as List;
      final catBreedImageList = jsonData.map((item) => $CatBreedImageResponseFromJson(item)).toList();
      return _catBreedImageListMapper.map(catBreedImageList);
    } else {
      throw Exception('Unexpected error with status ${response.statusCode} because of ${response.reasonPhrase}');
    }
  }
}
