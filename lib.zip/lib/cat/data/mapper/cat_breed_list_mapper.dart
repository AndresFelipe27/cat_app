
import 'package:flutter_application_1/cat/data/model/cat_breed_list/cat_breed_response.dart';

import '../../domain/model/cat_breed.dart';

final class CatBreedListMapper {
  List<CatBreed> map(List<CatBreedResponse> input) {
    return input
        .map(
          (item) => CatBreed(
            images: [],
            id: item.id,
            name: item.name,
            origin: item.origin,
            lifeSpan: item.lifeSpan,
            description: item.description,
            wikipediaUrl: item.wikipediaUrl,
            intelligence: item.intelligence,
          ),
        )
        .toList();
  }
}
