import 'package:genq/genq.dart';

import '../../../domain/model/cat_breed.dart';

part 'cat_breed_state.genq.dart';

@genq
class CatBreedState with _$CatBreedState {
  factory CatBreedState({
    required bool loading,
    required List<CatBreed> breeds,
    required CatBreed selectedBreed,
    Exception? error,
  }) = _CatBreedState;

  factory CatBreedState.empty() {
    return CatBreedState(
        breeds: [],
        error: null,
        loading: false,
        selectedBreed: CatBreed.empty(),
    );
  }
}
