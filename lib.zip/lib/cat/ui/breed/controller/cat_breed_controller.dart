import 'package:flutter_application_1/cat/ui/breed/model/cat_breed_state.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../domain/repository/cat_breed_repository.dart';

class CatBreedStateController extends StateNotifier<CatBreedState> {
  CatBreedStateController(
    this.catBreedRepository,
    super.state,
  ) : super() {
    fetchBreeds();
  }

  final CatBreedRepository catBreedRepository;

  void fetchBreeds() async {
    try {
      state = state.copyWith(loading: true);
      final breeds = await catBreedRepository.fetchBreeds();
      final breedImages = await catBreedRepository.fetchBreedImages(breeds.first.id);
      state = state.copyWith(
        loading: false,
        breeds: breeds,
        selectedBreed: breeds.first.copyWith(images: breedImages),
      );
    } catch (exception) {
      state = state.copyWith(loading: false, error: exception as Exception);
    }
  }

  void onBreedSelected(String newSelectedBreedId) async {
      state = state.copyWith(loading: true);
    final breedImages = await catBreedRepository.fetchBreedImages(newSelectedBreedId);
    state = state.copyWith(
      loading: false,
      selectedBreed: state.breeds.firstWhere(
        (element) => element.id == newSelectedBreedId
      ).copyWith(images: breedImages)
    );
  }
}
