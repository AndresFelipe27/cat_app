import 'package:flutter/material.dart';
import 'cat/ui/breed/cat_breed_screen.dart'; // Importar la Pantalla 1
import 'screen_two.dart'; // Importar la Pantalla 2

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<Widget> _widgetOptions = <Widget>[
    CatBreedScreen(),
    const ProfileScreen(), 
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70), // Altura personalizada para el AppBar
        child: AppBar(
          // Gradiente en el fondo del AppBar
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.deepPurple, Colors.pink],  // Degradado de púrpura a rosa
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          title: _buildAppTitle(),  // Título personalizado
          centerTitle: true,
          elevation: 0,  // Sin sombra para mantener el estilo limpio
        ),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.pets),
            label: 'Breeds',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.thumb_up),
            label: 'Vote',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildAppTitle() {
    return RichText(
      text: TextSpan(
        style: const TextStyle(
          fontSize: 30,
          fontWeight: FontWeight.bold,
          fontFamily: 'Pacifico', // Fuente personalizada (si la tienes)
          letterSpacing: 2.0,
        ),
        children: [
          TextSpan(
            text: 'Cat ',
            style: TextStyle(
              color: Colors.white,  // Color cálido para la palabra "Cat"
              shadows: [
                Shadow(
                  blurRadius: 10.0,
                  color: Colors.black.withOpacity(0.5),
                  offset: const Offset(5, 5),
                ),
              ],
            ),
          ),
          TextSpan(
            text: 'App',
            style: TextStyle(
              color: Colors.white,  // Color blanco para la palabra "App"
              shadows: [
                Shadow(
                  blurRadius: 10.0,
                  color: Colors.black.withOpacity(0.5),
                  offset: const Offset(5, 5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
