import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';  // Importa el WebView

class WebViewScreen extends StatefulWidget {
  final String url;

  const WebViewScreen({super.key, required this.url});

  @override
  _WebViewScreenState createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late WebViewController _webViewController;

  @override
  void initState() {
    super.initState();
    // Inicializa el WebView
    _initializeWebViewController();
  }

  // Inicializamos el WebViewController
  void _initializeWebViewController() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));  // Cargamos la URL recibida
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wikipedia'),
        backgroundColor: Colors.blue,
      ),
      body: WebViewWidget(
        controller: _webViewController,  // Usamos el controlador para el WebView
      ),
    );
  }
}
